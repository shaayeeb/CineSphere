﻿using System;

namespace BackEnd.Models
{
    public class Show
    {
        public int ShowId { get; set; } 
        public DateTime ShowDateTime { get; set; }
        public string? Note { get; set; }
    }


}
