﻿using System;

namespace BackEnd.DTO.Show
{
    public class ShowDTO
    {
        public int ShowId { get; set; }
        public string ShowDateTime { get; set; }
        public string Note { get; set; }
    }
}
