﻿namespace BackEnd.DTO.Seat
{
    public class CinemaHallDTO
    {
        public int CinemaHallId { get; set; }
        public string Name { get; set; }
        public int Capacity { get; set; }
    }
}
