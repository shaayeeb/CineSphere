﻿namespace BackEnd.DTO.Seat
{
    public class CreateSeatsDTO
    {
        public int NumberOfSeats { get; set; }
        public int CinemaHallId { get; set; }
    }
}
